import './App.css';

import StudentList from "./components/StudentList";
import StudentForm from "./components/StudentForm";
import useStudent from "./hooks/useStudent";

function App() {

    const {
        loading,
        error,
        loadStudents
    } = useStudent();

    if (loading) {
        return <p>Loading students...</p>;
    }

    if (error) {
        return (
            <div>
                <p>{error}</p>

                <button onClick={loadStudents}>
                    Retry
                </button>
            </div>
        );
    }

    return (
        <div>

            <h1>StudentApp</h1>

            <StudentList />

            <StudentForm />

        </div>
    );
}

export default App;