import { createStudent } from "../services/studentService";
import useStudent from "../hooks/useStudent";
import { useState } from "react";

function StudentForm() {

    const {
        handleStudentCreated
    } = useStudent();

    const [id, setId] = useState("");
    const [name, setName] = useState("");
    const [age, setAge] = useState("");

    async function handleSubmit(event) {
        event.preventDefault();

        const student = {
            id: Number(id),
            name: name,
            age: Number(age)
        };

        try {

            const createdStudent = await createStudent(student);

            handleStudentCreated(createdStudent);

            setId("");
            setAge("");
            setName("");

        } catch (error) {
            console.error(error);
        }
    }

    return (
        <form onSubmit={handleSubmit}>

            <input
                value={id}
                onChange={event => setId(event.target.value)}
                placeholder="ID"
            />

            <input
                value={name}
                onChange={event => setName(event.target.value)}
                placeholder="Name"
            />

            <input
                value={age}
                onChange={event => setAge(event.target.value)}
                placeholder="Age"
            />

            <button type="submit">
                Add Student
            </button>

        </form>
    );
}

export default StudentForm;