import  useStudent  from "../hooks/useStudent";

import StudentCard from "./StudentCard";

function StudentList() {
    const {
        students,
        handleDelete,
        handleStudentUpdated    
    } = useStudent();

   if (students.length === 0) {
        return <p>No students found.</p>;
    }

    return (
        <div>
            {students.map((student) => (
                <StudentCard
                    key={student.id}
                    student={student}
                    onStudentUpdated={handleStudentUpdated}
                    onDelete={handleDelete}
                />
            ))}           
        </div>
    );
}

export default StudentList;