import {
    createContext,
    useCallback,
    useEffect,
    useState
} from "react";

import {
    getStudents,
    deleteStudent
} from "../services/studentService";

const StudentContext = createContext();

function StudentProvider({ children }) {

    const [students, setStudents] = useState([]);

    const [loading, setLoading] = useState(true);

    const [error, setError] = useState("");

 // GET students
    const loadStudents = useCallback(async () => {

    try {
        setLoading(true);
        setError("");

        const data = await getStudents();

        setStudents(data);

    } catch (error) {
        setError("Failed to load students");

    } finally {
        setLoading(false);
    }

}, []);


useEffect(() => {

    loadStudents();

}, [loadStudents]);


// POST student
    function addStudent(student) {

        setStudents(previousStudents => [
            ...previousStudents,
            student
        ]);
    }

// PUT student
    function handleEdit(student) {
        setUpdate(student);
    }

    function updateStudent(updatedStudent) {     
        
        console.log("3. App received:", updatedStudent);

        setStudents(previousStudents => 
            previousStudents.map(student =>
                student.id === updatedStudent.id
                ? updatedStudent
                : student
            )            
        );
    }    


    // DELETE student
    async function removeStudent(id) {

        try {

            await deleteStudent(id);

            setStudents(previousStudents =>
                previousStudents.filter(
                    student => student.id !== id
                )
            );

        } catch (error) {

            console.error(error);

        }
    }

    return (
        <StudentContext.Provider
        value={{
            students,
            loading,
            error,
            loadStudents,
            addStudent,
            //handleEdit,
            updateStudent,
            removeStudent,      
        }}
        >
            {children}
        </StudentContext.Provider>
    );
}

export {
    StudentContext,
    StudentProvider
};